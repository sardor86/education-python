from .circle import circle_area, circle_perimeter
from .triangle import triangle_perimetr
from .square import square_area, square_perimetr
