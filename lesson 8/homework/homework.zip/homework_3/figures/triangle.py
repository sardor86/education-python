default_side_a = 7
default_side_b = 2
default_side_c = 8


def triangle_perimetr(side_a=default_side_a, side_b=default_side_b,
                      side_c=default_side_c): return side_a + side_b + side_c


__all__ = ("triangle_perimetr",)
