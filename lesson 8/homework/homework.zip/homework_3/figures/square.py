default_side_a = 15


def square_perimetr(side_a=default_side_a): return 4 * side_a


def square_area(side_a=default_side_a): return side_a ** 2

