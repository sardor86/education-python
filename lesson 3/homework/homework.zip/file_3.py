numbers = input("Введите числа: ")

list_num = numbers.split(", ")
tuple_num = tuple(numbers.split(", "))
print(list_num)
print(tuple_num)