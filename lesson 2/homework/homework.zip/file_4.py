num_1 = int(input("Введите первое число: "))
num_2 = int(input("Введите второе число: "))

multiplication = num_1 * num_2

if multiplication > 1000:
    print(f"Сумма равна {num_1 + num_2}")
else:
    print(f"Произведение равна {multiplication}")
